#include<iostream>
#include<string>
#include "utils.h"
#include "chargeTrainingSet.h"
#include "chargeTestSet.h"
#include "classifier.h"

long double nbayes(string mlnp, string usf, string trainingFile, string testFile, string resultFile);
